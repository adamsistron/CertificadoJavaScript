jQuery(document).ready(function($){
$("#commentForm").validate();
});